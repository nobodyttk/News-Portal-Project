// src/app/bing/page.js
'use client'; // Marque como Client Component para usar useState e fetch no browser

import { useState } from 'react';

export default function BingIndexNowPage() {
  const [key, setKey] = useState('');
  const [baseUrl, setBaseUrl] = useState('https://donghuahub.net/videos/alchemy-supreme-episodio-');
  const [startEpisode, setStartEpisode] = useState('');
  const [endEpisode, setEndEpisode] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResults([]);
    setMessage('');

    try {
      const response = await fetch('/api/indexnow', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          key,
          baseUrl,
          startEpisode: parseInt(startEpisode),
          endEpisode: parseInt(endEpisode),
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setResults(data.results);
        setMessage(data.message);
      } else {
        setMessage(`Erro: ${data.message || 'Ocorreu um erro desconhecido.'}`);
      }
    } catch (error) {
      console.error('Erro ao enviar requisição para o endpoint:', error);
      setMessage(`Erro de conexão: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: 'auto', fontFamily: 'Arial, sans-serif' }}>
      <h1>Submissão IndexNow para Episódios</h1>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
        <div>
          <label htmlFor="key" style={{ display: 'block', marginBottom: '5px' }}>Chave da IndexNow:</label>
          <input
            type="text"
            id="key"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            required
            style={{ width: '100%', padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
          />
        </div>
        <div>
          <label htmlFor="baseUrl" style={{ display: 'block', marginBottom: '5px' }}>Link Base (ex: https://site.com/videos/serie-episodio-):</label>
          <input
            type="text"
            id="baseUrl"
            value={baseUrl}
            onChange={(e) => setBaseUrl(e.target.value)}
            required
            style={{ width: '100%', padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
          />
        </div>
        <div style={{ display: 'flex', gap: '15px' }}>
          <div style={{ flex: 1 }}>
            <label htmlFor="startEpisode" style={{ display: 'block', marginBottom: '5px' }}>Episódio Inicial:</label>
            <input
              type="number"
              id="startEpisode"
              value={startEpisode}
              onChange={(e) => setStartEpisode(e.target.value)}
              required
              min="1"
              style={{ width: '100%', padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
            />
          </div>
          <div style={{ flex: 1 }}>
            <label htmlFor="endEpisode" style={{ display: 'block', marginBottom: '5px' }}>Episódio Final:</label>
            <input
              type="number"
              id="endEpisode"
              value={endEpisode}
              onChange={(e) => setEndEpisode(e.target.value)}
              required
              min="1"
              style={{ width: '100%', padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={loading}
          style={{
            padding: '10px 15px',
            backgroundColor: '#0070f3',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: loading ? 'not-allowed' : 'pointer',
            opacity: loading ? 0.7 : 1,
          }}
        >
          {loading ? 'Enviando...' : 'Enviar para IndexNow'}
        </button>
      </form>

      {message && <p style={{ marginTop: '20px', fontWeight: 'bold' }}>{message}</p>}

      {results.length > 0 && (
        <div style={{ marginTop: '30px', borderTop: '1px solid #eee', paddingTop: '20px' }}>
          <h2>Resultados da Submissão:</h2>
          <ul style={{ listStyleType: 'none', padding: 0 }}>
            {results.map((result, index) => (
              <li key={index} style={{ marginBottom: '10px', padding: '10px', backgroundColor: result.success ? '#e6ffe6' : '#ffe6e6', borderRadius: '4px' }}>
                <strong>URL:</strong> {result.url} <br />
                <strong>Status:</strong> {result.status} {result.success ? '(Sucesso)' : '(Falha)'} <br />
                {result.error && <span style={{ color: 'red' }}>Erro: {result.error}</span>}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}