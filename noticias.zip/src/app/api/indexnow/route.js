// src/app/api/indexnow/route.js
import { NextResponse } from 'next/server';

// Função para fazer a requisição POST para a IndexNow
async function submitUrlToIndexNow(urlToSubmit, apiKey) {
  const indexNowApiUrl = 'https://api.indexnow.org/indexnow';
  const requestBody = {
    host: new URL(urlToSubmit).hostname, // Extrai o host da URL a ser submetida
    key: apiKey,
    urlList: [urlToSubmit],
  };

  try {
    const response = await fetch(indexNowApiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    if (response.ok) {
      console.log(`[SUCESSO] IndexNow para ${urlToSubmit}. Status: ${response.status}`);
      return { success: true, url: urlToSubmit, status: response.status };
    } else {
      const errorText = await response.text();
      console.error(`[FALHA] IndexNow para ${urlToSubmit}. Status: ${response.status}, Resposta: ${errorText}`);
      return { success: false, url: urlToSubmit, status: response.status, error: errorText };
    }
  } catch (error) {
    console.error(`[ERRO DE CONEXÃO] IndexNow para ${urlToSubmit}. Erro: ${error.message}`);
    return { success: false, url: urlToSubmit, error: error.message };
  }
}

export async function POST(request) {
  try {
    const { key, baseUrl, startEpisode, endEpisode } = await request.json();

    if (!key || !baseUrl || typeof startEpisode === 'undefined' || typeof endEpisode === 'undefined') {
      return NextResponse.json(
        { message: 'Parâmetros inválidos. Key, baseUrl, startEpisode e endEpisode são obrigatórios.' },
        { status: 400 }
      );
    }

    const results = [];
    for (let i = startEpisode; i <= endEpisode; i++) {
      const urlToSubmit = `${baseUrl}${i}`;
      const result = await submitUrlToIndexNow(urlToSubmit, key);
      results.push(result);
    }

    return NextResponse.json({
      message: 'Processo de submissão para IndexNow concluído.',
      results: results,
    }, { status: 200 });

  } catch (error) {
    console.error('Erro na requisição para /api/indexnow:', error);
    return NextResponse.json(
      { message: 'Erro interno do servidor', error: error.message },
      { status: 500 }
    );
  }
}